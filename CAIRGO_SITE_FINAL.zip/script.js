document.getElementById("adminBtn").onclick = function () {
  alert("Connexion admin simulée.");
};