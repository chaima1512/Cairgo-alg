
function openLogin() {
    document.getElementById("loginPopup").style.display = "block";
}
function closeLogin() {
    document.getElementById("loginPopup").style.display = "none";
}
