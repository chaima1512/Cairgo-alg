
console.log("CAIRGO dashboard ready.");
